
class Incentive:
    
    
    @staticmethod
    def calculate_incentive(start_dist, ):
