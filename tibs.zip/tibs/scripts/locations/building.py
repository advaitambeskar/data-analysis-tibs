from collections import namedtuple

Building = namedtuple("Building", "building lat lon density")