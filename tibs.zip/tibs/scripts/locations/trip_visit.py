from collections import namedtuple

Visit = namedtuple("Visit", "building lat lon start duration")

Visit_Marker = namedtuple("Visit_Marker", "building lat lon title")